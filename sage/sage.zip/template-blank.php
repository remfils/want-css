<?php
/**
 * Template Name: Blank Template
 */
while (have_posts()) : the_post(); ?>
<?php the_content();?>
<?php endwhile; ?>